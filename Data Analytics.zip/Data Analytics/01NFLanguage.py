f=open("Netflix.csv","r")
lang=input('Enter Language:')
cnt=0
tot=0

for rec in f:
    tot+=1
    if rec.split(',')[1].upper()==lang.upper:()
    cnt+=1


print('Total %s movies of the Language : %d' %(lang,cnt))
perc=cnt*100/tot
print('Percentage of %s movies in the Language %.2f%%' %(lang,perc))
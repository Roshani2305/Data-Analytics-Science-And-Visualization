f=open("Netflix.csv","r")
lang=input('Enter Language:')

tot=0
cnt=0
hit=0
flop=0

tot=cnt=hit=flop=0

for rec in f:
    tot+=1
    if rec.split(',')[1].upper()==lang.upper():
        if float(rec.split(',')[3]) >= 7:
           hit+=1
        if float(rec.split(',')[3]) <= 4:
           flop+=1

print ('Total hits show of %s are %d' %(lang,hit))
print ('Total flops show of %s are %d' %(lang,flop))
perc=hit*100/cnt
print('percent of %s hits of language %.2f%%' %(lang,perc))
perc=flop*100/cnt
print('Percent of %s flop of Language %.2f%%' %(lang,perc))   
